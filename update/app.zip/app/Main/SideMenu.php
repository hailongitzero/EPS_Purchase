<?php

namespace App\Main;

class SideMenu
{
    /**
     * List of side menu items.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public static function menu()
    {
        return [
            'dashboard' => [
                'devider' => false,
                'icon' => 'home',
                'route_name' => 'dashboard',
                'params' => [
                    'layout' => 'side-menu'
                ],
                'title' => 'Dashboard',
                'role' => [0,1,2],
            ],
            'makeRequest' => [
                'devider' => false,
                'icon' => 'edit',
                'route_name' => 'request.add.view',
                'params' => [
                    'layout' => 'side-menu'
                ],
                'title' => 'Tạo yêu cầu',
                'role' => [0,1,2],
            ],
            'administrator' => [
                'devider' => false,
                'icon' => 'layers',
                'route_name' => 'administrator',
                'params' => [
                    'layout' => 'side-menu'
                ],
                'title' => 'Quản lý yêu cầu',
                'role' => [2],
            ],
            'moderator' => [
                'devider' => false,
                'icon' => 'layers',
                'route_name' => 'moderator',
                'params' => [
                    'layout' => 'side-menu'
                ],
                'title' => 'Quản lý yêu cầu',
                'role' => [1],
            ],
            'myRequests' => [
                'devider' => false,
                'icon' => 'layers',
                'route_name' => 'myRequests',
                'params' => [
                    'layout' => 'side-menu'
                ],
                'title' => 'Yêu cầu của tôi',
                'role' => [0],
            ],
            'Quản lý thiết bị' => [
                'devider' => false,
                'icon' => 'monitor',
                'title' => 'Quản lý thiết bị',
                'sub_menu' => [
                    'Thiết bị' => [
                        'devider' => false,
                        'icon' => 'box',
                        'title' => 'Thiết bị',
                        'sub_menu' => [
                            'Danh sách' => [
                                'icon' => 'menu',
                                'route_name' => 'assets',
                                'params' => [
                                    'layout' => 'side-menu'
                                ],
                                'title' => 'Danh sách',
                                'role' => [1,2],
                            ],
                            'Bảo trì' => [
                                'icon' => 'tool',
                                'route_name' => 'maintenances',
                                'params' => [
                                    'layout' => 'side-menu'
                                ],
                                'title' => 'Bảo trì',
                                'role' => [1,2],
                            ],
                            'Yêu cầu' => [
                                'icon' => 'file-text',
                                'route_name' => 'checkouts',
                                'params' => [
                                    'layout' => 'side-menu'
                                ],
                                'title' => 'DS Yêu cầu',
                                'role' => [1,2],
                            ],
                        ],
                        'role' => [1,2],
                    ],
                    'Bản quyền' => [
                        'devider' => false,
                        'icon' => 'file-text',
                        'title' => 'Bản quyền',
                        'route_name' => 'licenses',
                        'params' => [
                            'layout' => 'side-menu'
                        ],
                        'role' => [1,2],
                    ],
                    'Cài đặt' => [
                        'devider' => false,
                        'icon' => 'settings',
                        'title' => 'Cài đặt',
                        'sub_menu' => [
                            'Danh mục' => [
                                'icon' => 'layers',
                                'route_name' => 'categories',
                                'params' => [
                                    'layout' => 'side-menu'
                                ],
                                'title' => 'Danh mục',
                                'role' => [1,2],
                            ],
                            'Models' => [
                                'icon' => 'layers',
                                'route_name' => 'models',
                                'params' => [
                                    'layout' => 'side-menu'
                                ],
                                'title' => 'Models',
                                'role' => [1,2],
                            ],
                            'Nhà sản xuất' => [
                                'icon' => 'settings',
                                'route_name' => 'manufacturers',
                                'params' => [
                                    'layout' => 'side-menu'
                                ],
                                'title' => 'Nhà sản xuất',
                                'role' => [1,2],
                            ],
                            'Nhà cung cấp' => [
                                'icon' => 'truck',
                                'route_name' => 'Suppliers',
                                'params' => [
                                    'layout' => 'side-menu'
                                ],
                                'title' => 'Nhà cung cấp',
                                'role' => [1,2],
                            ],
                        ],
                        'role' => [1,2],
                    ],
                    'Yêu cầu' => [
                        'devider' => true,
                        'icon' => 'navigation',
                        'route_name' => 'requestables',
                        'params' => [
                            'layout' => 'side-menu'
                        ],
                        'title' => 'Yêu cầu',
                        'role' => [0,1,2],
                    ],
                ],
                'role' => [0,1,2],
            ],
            'userManagement' => [
                'devider' => true,
                'icon' => 'user',
                'route_name' => 'userManagement',
                'params' => [
                    'layout' => 'side-menu'
                ],
                'title' => 'Quản lý người dùng',
                'role' => [1,2],
            ],
            'file-manager' => [
                'devider' => true,
                'icon' => 'hard-drive',
                'route_name' => 'fileManage',
                'params' => [
                    'layout' => 'side-menu'
                ],
                'title' => 'Hướng dẫn sử dụng',
                'role' => [0,1,2],
            ]
        ];
    }
}
