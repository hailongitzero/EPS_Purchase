<?php

namespace App\Notifications;

use App\Main\Utils;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class completeRequest extends Notification implements ShouldQueue
{
    use Queueable;

    public $tries = 3;

    public $data;

    public $link;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($data, $link)
    {
        $this->data = $data;
        $this->link = $link;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $mail = (new MailMessage)
            ->subject('Thông báo '.$this->data['status'] == 'X' ? "từ chối" : "hoàn thành".' xử lý yêu cầu.')
            ->action('Chi tiết', url(config('app.url').$this->link))
            ->line('Họ tên ')
            ->line($this->data['requester']['name'])
            ->line('Phòng/PX ')
            ->line($this->data['department']['department_name'])
            ->line('Ngày tạo ')
            ->line($this->data['created_at'])
            ->line('Hạn xử lý ')
            ->line($this->data['complete_date'])
            ->line('Nội dung ')
            ->line($this->data['content'])
            ->markdown('emails.requestMail', [
                'status' => $this->data['status'],
                'subject' => $this->data['subject'],
                'statusList' => Utils::STATUS_LIST,
                ]);
        return $mail;
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
