<?php

namespace App\Notifications;

use App\Main\Utils;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class returnRequest extends Notification implements ShouldQueue
{
    use Queueable;

    public $tries = 3;

    public $data;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $mail = (new MailMessage)
            ->subject('Thông báo chuyển xử lý yêu cầu')
            ->action('Chi tiết', url(config('app.url').'/administrator?tab=extend-return-req-tab&id='.$this->data['request_id']))
            ->line('Người xử lý ')
            ->line($this->data['handler']['name'])
            ->line('Người tạo ')
            ->line($this->data['requester']['name'])
            ->line('Phòng/PX ')
            ->line($this->data['department']['department_name'])
            ->line('Ngày tạo ')
            ->line($this->data['created_at'])
            ->line('Hạn xử lý ')
            ->line($this->data['complete_date'])
            ->line('Nội dung ')
            ->line($this->data['content'])
            ->markdown('emails.requestMail', [
                'status' => $this->data['status'],
                'subject' => $this->data['subject'],
                'statusList' => Utils::STATUS_LIST,
                ]);
        return $mail;
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
